# Changelog

All Notable changes to `sped-gtin` will be documented in this file.

Todas as atualizações a partir de 30/03/2018 devem observar os princípios [Mantendo o CHANGELOG](http://keepachangelog.com/).

## 1.0.0-dev 

## Notas da versão:

### Added
- Nothing

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing
