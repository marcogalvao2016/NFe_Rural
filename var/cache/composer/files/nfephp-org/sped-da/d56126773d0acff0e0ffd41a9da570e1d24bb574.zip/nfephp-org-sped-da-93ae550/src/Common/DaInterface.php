<?php

namespace NFePHP\DA\Common;

interface DaInterface
{
    public function creditsIntegratorFooter($message);
    public function monta();
    public function render();
}
