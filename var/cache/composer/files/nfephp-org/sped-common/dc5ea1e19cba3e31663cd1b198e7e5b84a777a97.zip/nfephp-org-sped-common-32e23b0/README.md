![PHP Supported Version][ico-php]
![Actions](https://github.com/nfephp-org/sped-common/actions/workflows/ci.yml/badge.svg)
[![Latest Stable Version][ico-stable]][link-packagist]
[![Join the chat at https://gitter.im/nfephp-org/sped-common](https://badges.gitter.im/nfephp-org/sped-common.svg)](https://gitter.im/nfephp-org/sped-common?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

# sped-common

Classes comuns usadas nas atividades e classes das API de NFe, CTe, MDFe, e-Financeira, eSfinge, eSocial

# Version v5.1.x

# [Documentos](docs/README.md)

[ico-php]: https://img.shields.io/packagist/php-v/nfephp-org/sped-common
[ico-stable]: https://poser.pugx.org/nfephp-org/sped-common/version
[link-packagist]: https://packagist.org/packages/nfephp-org/sped-common
